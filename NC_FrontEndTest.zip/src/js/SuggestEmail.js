/*
 * SuggestEmail Class By Mohamed Husain
 */
function SuggestEmail() {
	this.providers = ['gmail', 'googlemail', 'hotmail', 'live', 'outlook', 'yahoo', 'mail', 'aol', 'gmx', 'aim', 'caramail', 'email', 'free', 'gawab', 'fastmail', 'hushmail', 'laposte', 'myspace', 'ymail', 'orange', 'rocketmail', 'yandex']
	this.topDomains = ['com', 'co.uk', 'uk', 'il', 'ru', 'org', 'se', 'dk', 'de', 'am', 'net', 'biz', 'de', 'email', 'edu', 'eu', 'fr', 'fm', 'gov', 'mil', 'hk', 'info', 'int', 'io', 'jp', 'mobi', 'ru', 'us', 'in', ]
}


//modified function , original from https://rosettacode.org/wiki/Levenshtein_distance#JavaScript
//get distance
SuggestEmail.prototype.levenshtein = function(a, b) {
	if (a == null || a.length === 0) {
		if (b == null || b.length === 0) {
			return 0
		} else {
			return b.length
		}
	}
	if (b == null || b.length === 0) {
		return a.length
	}
	var c = 0;
	var offset1 = 0;
	var offset2 = 0;
	var lcs = 0;
	var maxOffset = 5;
	while ((c + offset1 < a.length) && (c + offset2 < b.length)) {
		if (a.charAt(c + offset1) == b.charAt(c + offset2)) {
			lcs++
		} else {
			offset1 = 0;
			offset2 = 0;
			for (var i = 0; i < maxOffset; i++) {
				if ((c + i < a.length) && (a.charAt(c + i) == b.charAt(c))) {
					offset1 = i;
					break
				}
				if ((c + i < b.length) && (a.charAt(c) == b.charAt(c + i))) {
					offset2 = i;
					break
				}
			}
		}
		c++
	}
	return (a.length + b.length) / 2 - lcs;
}
//check if provider in the list
SuggestEmail.prototype.isProviderExist = function(provider) {
	for (var d = 0; d < this.providers.length; d++) {
		if (provider == this.providers[d]) {
			return true
		}
	}
	return false
}
//check if top Domai nExist
SuggestEmail.prototype.isTopDomainExist = function(topDomain) {
	for (var d = 0; d < this.topDomains.length; d++) {
		if (topDomain == this.topDomains[d]) {
			return true
		}
	}
	return false
}
//suggest email function
SuggestEmail.prototype.check = function(email) {
	email = email.toLowerCase()
		//console.log( 'email', email )
	var match = email.match(/^(.*)@/)
	if (!match || match.length < 2) {
		return null
	}
	var username = match[1]
		//console.log( 'username', username )
	match = email.match(/@(.*)\./)
	if (!match || match.length < 2) {
		return null
	}
	var provider = match[1]
	match = email.match(/\.(.*)$/)
	if (!match || match.length < 2) {
		return null
	}
	var topDomain = match[1]
	var suggest = {
		username: username,
		provider: provider,
		topDomain: topDomain,
		result: ''
	}
	var mdd = 99
	var mdtd = 99
	var domainFound = this.isProviderExist(provider)
	var topDomainFound = this.isTopDomainExist(topDomain)
	if (!domainFound || !topDomainFound) {
		if (!domainFound) {
			for (var d = 0; d < this.providers.length; d++) {
				var sd = this.providers[d]
				var dd = this.levenshtein(provider, sd)
				if (dd < mdd) {
					suggest.provider = sd
					mdd = dd
				}
			}
		}
		if (!topDomainFound) {
			for (var d = 0; d < this.topDomains.length; d++) {
				var std = this.topDomains[d]
				var dtd = this.levenshtein(topDomain, std)
				if (dtd < mdtd) {
					suggest.topDomain = std
					mdtd = dtd
				}
			}
		}
		suggest.result = suggest.username + '@' + suggest.provider + '.' + suggest.topDomain
		return suggest
	}
	return null
}