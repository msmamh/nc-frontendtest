/*
 * app
 */
var app = new Vue({
		el: '#app',
		data: {
			isValidEmail: false,
			isValidPassword: false,
			prevent: false,
			email: '',
			password: '',
			suggest: '',
			btn: 'Submit'
		},
		watch: {
			email: function(newEmail) {
				this.isValidEmail = newEmail.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) ? true : false
				if (!this.isValidEmail) this.doYouMean(newEmail)
			},
			password: function(newPwd) {
				this.isValidPassword = (newPwd != null && newPwd != '') ? true : false
			}
		},
		methods: {
			doYouMean: function(email) {
				var se = new SuggestEmail()
				var suggest = se.check(email)
				this.suggest = ((suggest != null && suggest != email) ? suggest.result : null)
			}
		}
	}) 